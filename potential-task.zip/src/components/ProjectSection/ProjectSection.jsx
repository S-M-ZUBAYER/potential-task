import React, { useState } from 'react';

const ProjectCard = ({ image, category, title, isDarkMode }) => {
console.log(isDarkMode);


  return (
    <div className={`rounded-xl overflow-hidden transition-all duration-300 ${
      isDarkMode ? 'bg-gray-800' : 'bg-white'
    }`}>
      <div className="relative group">
        <img
          src={image}
          alt={title}
          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300" />
      </div>
      <div className="p-4">
        <span className={`text-sm ${
          isDarkMode ? 'text-orange-400' : 'text-orange-500'
        }`}>
          {category}
        </span>
        <h3 className={`text-lg font-semibold mt-2 ${
          isDarkMode ? 'text-white' : 'text-black'
        }`}>
          {title}
        </h3>
      </div>
    </div>
  );
};

const ProjectsSection = ({ isDarkMode }) => {
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'UI/UX', 'Web Design', 'App Design', 'Graphic Design'];

  const projects = [
    {
      image: '/api/placeholder/400/300',
      category: 'Web Design',
      title: 'AirCalling Landing Page Design'
    },
    {
      image: '/api/placeholder/400/300',
      category: 'Web Design',
      title: 'Business Landing Page Design'
    },
    {
      image: '/api/placeholder/400/300',
      category: 'Web Design',
      title: 'Ecom Web Page Design'
    },
    // Add more projects as needed
  ];

  const filteredProjects = projects.filter(project => 
    activeFilter === 'All' ? true : project.category === activeFilter
  );

  return (
    <section className={`min-h-screen py-20 ${
      isDarkMode ? 'bg-gray-900' : 'bg-white'
    } transition-colors duration-300`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className={`text-3xl font-bold mb-4 ${
            isDarkMode ? 'text-white' : 'text-black'
          }`}>
            My Projects
          </h2>
          <p className={`max-w-2xl mx-auto text-base ${
            isDarkMode ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Lorem ipsum dolor sit amet consectetur. Mollis erat duis aliquam mauris est rius 
            lectus. Phaselius consequat urna tellus
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeFilter === filter
                  ? 'bg-orange-500 text-white'
                  : isDarkMode
                    ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <ProjectCard
              key={index}
              image={project.image}
              category={project.category}
              title={project.title}
              isDarkMode={isDarkMode}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// Remove the separate theme state and just pass through the props
const ProjectsWithTheme = ({ isDarkMode }) => {
  return <ProjectsSection isDarkMode={isDarkMode} />;
};

export default ProjectsWithTheme;